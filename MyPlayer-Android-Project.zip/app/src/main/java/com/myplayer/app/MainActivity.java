package com.myplayer.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    private WebView web;
    private LinearLayout bar;
    private View customView;
    private android.webkit.WebChromeClient.CustomViewCallback customCallback;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16,19,27));
        getWindow().setNavigationBarColor(Color.rgb(16,19,27));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(16,19,27));

        TextView title = new TextView(this);
        title.setText("▶  MyPlayer");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(18, 14, 12, 14);
        root.addView(title);

        bar = new LinearLayout(this);
        bar.setPadding(10, 6, 10, 10);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        EditText url = new EditText(this);
        url.setSingleLine(true);
        url.setTextColor(Color.WHITE);
        url.setHintTextColor(Color.LTGRAY);
        url.setHint("Paste video / VDiskPro link");
        url.setTextSize(14);
        url.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI );
        bar.addView(url, new LinearLayout.LayoutParams(0, 52, 1));

        Button go = new Button(this);
        go.setText("PLAY");
        go.setTextColor(Color.WHITE);
        go.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(105,80,230)));
        bar.addView(go);
        root.addView(bar);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                customView = view; customCallback = callback;
                bar.setVisibility(View.GONE); title.setVisibility(View.GONE); web.setVisibility(View.GONE);
                root.addView(view, new LinearLayout.LayoutParams(-1, -1));
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            }
            @Override public void onHideCustomView() {
                if (customView != null) root.removeView(customView);
                customView = null;
                bar.setVisibility(View.VISIBLE); title.setVisibility(View.VISIBLE); web.setVisibility(View.VISIBLE);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                if (customCallback != null) customCallback.onCustomViewHidden();
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        go.setOnClickListener(v -> {
            String link = url.getText().toString().trim();
            if (!link.isEmpty()) {
                if (!link.startsWith("https://") && !link.startsWith("http://")) link = "https://" + link;
                web.loadUrl(link);
            }
        });
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
